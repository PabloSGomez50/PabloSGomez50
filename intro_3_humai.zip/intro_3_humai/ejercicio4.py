def pedir_opcion(opciones: list, mensaje='Ingresar informacion:') -> str:
    
    while True:
        respuesta = input(mensaje).lower()

        if respuesta in opciones:
            return respuesta

